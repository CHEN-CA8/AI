import pandas as pd
from causis_api.common_data import get_price

def fetch_data(product_code,start_date,end_date,frequency='day', fields=None, skip_suspended =False, market='cn', expect_df=False):
    try:
        start_date = str(start_date)
        end_date = str(end_date)
        start_Date = pd.to_datetime(start_date, format='%Y-%m-%d')
        end_Date = pd.to_datetime(end_date, format='%Y-%m-%d')
        # 获取数据
        data = get_price(product_code,start_date, end_date=None, frequency='day', fields=None, skip_suspended =False, market='cn', expect_df=False)
        data=data.drop(columns=['SYMBOL'])
        data['CLOCK'] = pd.to_datetime(data['CLOCK'], format='%Y-%m-%d')
        data = data.set_index('CLOCK')
        return data

    except Exception as e:
        print(f"产生错误 {product_code}: {e}")
        return None


