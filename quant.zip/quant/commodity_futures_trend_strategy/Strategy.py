import pandas as pd

class Strategy():

    def Genetate_signal(self, data, short, long, lookback=5):

        # 计算移动均线
        ma5 = data['CLOSE'].rolling(short).mean()
        ma30 = data['CLOSE'].rolling(long).mean()
        # 计算金叉和死叉信号
        s1 = ma5 < ma30
        s2 = ma5 > ma30
        death_ex = (s1 & s2.shift(1))
        golden_ex = ~(s1 | s2.shift(1))
        death_date = ma5.index[death_ex]
        golden_date = ma5.index[golden_ex]

        s1 = pd.Series(data=1, index=golden_date)
        s2 = pd.Series(data=0, index=death_date)
        S = pd.concat([s1, s2]).sort_index()

        data['momentum'] = data['CLOSE'] - data['CLOSE'].shift(lookback)
        final_signals = pd.Series(index=S.index, dtype=int)

        for i in S.index:
            if S.get(i, 0) == 1 and data['momentum'].loc[i] > 0:
                final_signals.loc[i] = 0
            elif S.get(i, 0) == 0 and data['momentum'].loc[i] < 0:
                final_signals.loc[i] = 1

        final_signals = final_signals.dropna()

        return final_signals
