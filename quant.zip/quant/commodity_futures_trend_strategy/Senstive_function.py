
import pandas as pd

import commodity_futures_trend_strategy
from commodity_futures_trend_strategy.HuiCe import BacktestEngine

from commodity_futures_trend_strategy.Strategy import Strategy
def sensitivity_analysis( data, short_range, long_range, metric="Annualized Return"):
    print(f"data: {type(data)}, short_range: {short_range}, long_range: {long_range}, metric: {metric}")
    results = []
    for short in short_range:
        row = []
        for long in long_range:
            if short >= long:
                row.append(None)  # 排除无效组合
                continue

            # 运行回测
            strategy=Strategy()
            signals = strategy.Genetate_signal(data, short, long)
            back=BacktestEngine()
            back.execute_trades(data, signals)
            performance = back.analyze_results()

            # 记录指定指标
            row.append(performance[metric])
        results.append(row)

    # 转换为 DataFrame，方便可视化
    sensitivity_matrix = pd.DataFrame(
        results, index=short_range, columns=long_range
    )
    return sensitivity_matrix