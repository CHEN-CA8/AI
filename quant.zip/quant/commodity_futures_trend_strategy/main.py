from commodity_futures_trend_strategy.HuiCe import BacktestEngine
from commodity_futures_trend_strategy.Senstive_function import sensitivity_analysis
from commodity_futures_trend_strategy.data_management import fetch_data
from commodity_futures_trend_strategy.Strategy import Strategy
from commodity_futures_trend_strategy.draw import StrategyVisualizer
import matplotlib.pyplot as plt
import numpy as np

if __name__ == "__main__":
    # 加载数据
    product_code = 'R.CN.CZC.TA.0004'

    data=fetch_data(product_code,start_date='2010-01-01',end_date='2024-12-5')
    print(data)

    back = BacktestEngine()
    strategy = Strategy()
    signals=strategy.Genetate_signal(data,7,40,5)

    # 执行回测
    net_value_history = back.execute_trades(data, signals)

    # 输出结果分析
    performance_metrics = back.analyze_results()

    trade_buy = back.trade_buy
    trade_sell = back.trade_sell
    initial_balance=back.initial_balance

    visualizer = StrategyVisualizer(data, signals, net_value_history, trade_buy, trade_sell, initial_balance)
    visualizer.plot_signals()
    visualizer.plot_position()
    visualizer.plot_pnl()
    performance_metrics = back.analyze_results()
    visualizer.plot_performance_metrics(performance_metrics)
    short_range = [7,10,15,20,30]
    long_range = [40, 50, 70,90,100]
    sensitivity_matrix = sensitivity_analysis(data, short_range, long_range, metric="Annualized Return")
    visualizer.plot_sensitivity(sensitivity_matrix, short_range, long_range)
