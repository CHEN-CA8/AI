import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import pandas as pd
from commodity_futures_trend_strategy.HuiCe import BacktestEngine
from commodity_futures_trend_strategy.data_management import fetch_data
from pylab import mpl
mpl.rcParams['font.sans-serif']=['SimHei']
mpl.rcParams['axes.unicode_minus']=False
class StrategyVisualizer():

    def __init__(self, data, signals, net_value_history, trade_buy, trade_sell,initial_balance ):
        self.data = data
        self.signals = signals  # 买入/卖出信号 (Series)
        self.net_value_history = net_value_history  # 策略的净值历史
        self.trade_buy = trade_buy  # 买入交易记录
        self.trade_sell = trade_sell  # 卖出交易记录
        self.initial_balance=initial_balance


    def plot_signals(self):
        """画出买入卖出信号图"""
        plt.figure(figsize=(14, 8))
        plt.plot(self.data['CLOSE'], label='Close Price', color='blue')
        self.signals = self.signals.reindex(self.data.index, method='ffill')
        buy_signal = self.data.loc[self.signals == 1, 'CLOSE']
        sell_signal = self.data.loc[self.signals == 0, 'CLOSE']
        plt.plot(buy_signal.index, buy_signal, color='g', label='Buy Signal', linestyle='-', linewidth=1)
        plt.plot(sell_signal.index, sell_signal, color='r', label='Sell Signal', linestyle='-',linewidth=1)
        plt.title('Buy and Sell Signals')
        plt.legend()
        plt.show()

    def plot_position(self):
        """画出仓位变化图"""
        position = [0]  # 初始仓位为0
        cash = [self.initial_balance]
        for i in range(1, len(self.signals)):
            position.append(position[-1] + (self.signals[i] == 1) - (self.signals[i] == 0))
            cash.append(cash[-1] + (self.signals[i] == 1) - (self.signals[i] == 0))
        plt.figure(figsize=(14, 8))
        plt.plot(self.data.index[1:], position[1:], label='仓位', color='orange')

        plt.title('仓位变化图')
        plt.xlabel('时间')
        plt.ylabel('仓位')
        plt.legend()
        plt.show()
    def plot_pnl(self):
        """画出PNL曲线图"""
        plt.figure(figsize=(14, 8))
        plt.plot(self.net_value_history, label='Net Value', color='blue')
        plt.title('PNL Curve')
        plt.legend()
        plt.show()

    def plot_performance_metrics(self, performance_metrics):
        """策略性能指标表"""
        metrics_df = pd.DataFrame(performance_metrics, index=[0])
        print(metrics_df)

    def plot_sensitivity(self, sensitivity_matrix, short_range, long_range):
        """
        绘制参数敏感度热力图
        """
        plt.figure(figsize=(10, 8))
        sns.heatmap(
            sensitivity_matrix, annot=True, fmt=".2f", xticklabels=long_range, yticklabels=short_range, cmap="coolwarm"
        )
        plt.title("Parameter Sensitivity Analysis")
        plt.xlabel("长日均线")
        plt.ylabel("短日均线")
        plt.show()

