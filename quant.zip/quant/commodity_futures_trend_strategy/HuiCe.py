import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from commodity_futures_trend_strategy.data_management import fetch_data
from commodity_futures_trend_strategy.Strategy import Strategy
class BacktestEngine:
    def __init__(self, initial_balance=1000000):

        self.initial_balance = initial_balance
        self.balance = initial_balance
        self.position = 0
        self.trade_sell = []
        self.trade_buy = []
        self.net_value_history = []
        self.net_value_history_data = 0



    def execute_trades(self, data,S):
        """
        执行交易，根据信号调整仓位和资金
        """
        cash = self.initial_balance
        position = 0
        price_break_threshold = 0.01  # 1% 的突破
        transsation_rate=0.001

        self.net_value_history = []

        for i in S.index:

            price_open=data.loc[i,'OPEN']
            price_close=data.loc[i,'CLOSE']

               # 买入信号
            if S.loc[i]==0 and cash > 0:
                buy_quantity = cash // (price_open * 50)
                cash -= buy_quantity * price_open * 50-(buy_quantity * price_open)*transsation_rate
                position += buy_quantity
                self.trade_buy.append((i, price_open))

            # 卖出信号
            elif S.loc[i]==1 and position > 0 :
                cash += position * price_close * 50-(position * price_close * 50)*transsation_rate
                self.trade_sell.append((i, price_close))
                position = 0

            # 记录净值
            net_value = cash + position * price_close * 50-(position * price_close)*transsation_rate
            self.net_value_history.append(net_value)


        # 持有的股票在最后一个交易日清仓
        if position > 0:
            final_price = data.iloc[-1]['CLOSE']
            cash += position * final_price * 50-(position * final_price * 50)*transsation_rate
            position = 0

        # 最终净值
        final_net_value = cash
        print(f"最终净值: {final_net_value}")
        return self.net_value_history

    def analyze_results(self):
        net_values = np.array(self.net_value_history)
        returns = np.diff(net_values) / net_values[:-1]
        annualized_return = (net_values[-1] / net_values[0]) ** (252 / len(net_values)) - 1
        volatility = np.std(returns) * np.sqrt(252)
        risk_free_rate = 0.02
        sharpe_ratio = (annualized_return - risk_free_rate) / volatility
        drawdown = net_values / np.maximum.accumulate(net_values) - 1
        max_drawdown = drawdown.min()
        calmar_ratio = annualized_return / abs(max_drawdown)
        print("策略性能指标：")
        print(f"年化收益率: {annualized_return:.2%}")
        print(f"波动率: {volatility:.2%}")
        print(f"夏普比率: {sharpe_ratio:.2f}")
        print(f"最大回撤: {max_drawdown:.2%}")
        print(f"卡玛比率: {calmar_ratio:.2f}")
        return {
            "Annualized Return": annualized_return,
            "Volatility": volatility,
            "Sharpe Ratio": sharpe_ratio,
            "Max Drawdown": max_drawdown,
            "Calmar Ratio": calmar_ratio,
        }





