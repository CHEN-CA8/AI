import requests
import pandas as pd

common_url = 'http://58.49.210.250:9999/'#生产端口http://db.causis.com.cn:9999/;测试端口http://192.168.0.150:9999
# common_url = 'http://192.168.0.150:9999/'

# 中文常量类
class Cn(object):
    total_return = '总收益'
    annual_return = '年化收益'
    sharpe = '夏普比率'
    volatility = '波动率'
    sortino = '索提诺比率'
    downside_volatility = '下行波动率'
    max_drawback = '最大回撤'
    max_drawback_start = '最大回撤起始'
    max_drawback_end = '最大回撤到达'
    longest_drawback_period = '最大回撤周期'
    longest_drawback_start = '最大回撤周期起始'
    longest_drawback_end = '最大回撤周期结束'

# 获取Python序列号，作为Python接口的通信标志
def get_python_No():
    url = common_url + 'get_pythonNo?' 
    resp = requests.get(url)
    No = resp.json()['Data']
    return No
# 获取版本号
def get_version():
    url = common_url + 'get_version?' 
    resp = requests.get(url)
    version = resp.json()['Data']
    return version

# 登录账号以及密码
class login(object):
    username = 'xuanyu.chen'
    password = '18173358826cxY'
    # version = None
    pythonNo = get_python_No()
    version = get_version()
    common_url = common_url





# 数据常量类
class Data(object):
    stock_price_standard = None
    index_price_standard = None
    stock_valuation_standard = None

# 行业分类   
class Industry(object):
    '''
    行业分类会随时间变化
    '''
    sw1 = pd.Series(['S.CN.INBS.801130', 'S.CN.INBS.801110', 'S.CN.INBS.801140',
       'S.CN.INBS.801150', 'S.CN.INBS.801790', 'S.CN.INBS.801210',
       'S.CN.INBS.801050', 'S.CN.INBS.801230', 'S.CN.INBS.801020',
       'S.CN.INBS.801180', 'S.CN.INBS.801710', 'S.CN.INBS.801770',
       'S.CN.INBS.801010', 'S.CN.INBS.801030', 'S.CN.INBS.801160',
       'S.CN.INBS.801720', 'S.CN.INBS.801120', 'S.CN.INBS.801040',
       'S.CN.INBS.801890', 'S.CN.INBS.801200', 'S.CN.INBS.801880',
       'S.CN.INBS.801780', 'S.CN.INBS.801730', 'S.CN.INBS.801170',
       'S.CN.INBS.801080', 'S.CN.INBS.801740', 'S.CN.INBS.801760',
       'S.CN.INBS.801750', 'S.CN.INBS.801950', 'S.CN.INBS.801960',
       'S.CN.INBS.801970', 'S.CN.INBS.801980'],
       index=['纺织服装I', '家用电器I', '轻工制造I', '医药生物I', '非银金融I', '休闲服务I', '有色金属I', '综合I',
       '采掘I', '房地产I', '建筑材料I', '通信I', '农林牧渔I', '化工I', '公用事业I', '建筑装饰I',
       '食品饮料I', '钢铁I', '机械设备I', '商业贸易I', '汽车I', '银行I', '电气设备I', '交通运输I', '电子I',
       '国防军工I', '传媒I', '计算机I', '煤炭I', '石油石化I', '环保I', '美容护理I'])#20211211，减少了采掘，增加了'煤炭I', '石油石化I', '环保I', '美容护理I'
        # S.CN.INBS.801020 采掘I 剔除
if __name__ == '__main__':
    # 接口测试
    print(login.username)
    login.username = 'xx'
    print(login.username)