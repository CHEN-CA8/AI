#从服务器提取原始数据并整理成标准格式，方便因子计算
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
import requests
import pandas as pd
import numpy as np
import datetime as dt
import progressbar
from causis_api.const import login
from causis_api.const import Industry
from causis_api.common_data import all_instruments
from causis_api.common_data import get_trading_dates

username = login.username
password = login.password
version = login.version

common_url = login.common_url
common_user = '?username=' + username + '&password=' + password + '&version=' + version + '&pythonNo=' + login.pythonNo


def price_standard(price_ori):
    '''
    将原始数据转换为标准的格式
    '''

    # 生成双重索引的index
    code_list = list(price_ori['Symbol'].drop_duplicates(keep='first'))
    #ziduan = list(price_ori.columns)
    ziduan = ['Open', 'Close', 'High', 'Low', 'Limit_Up', 'Limit_Down', 'Total_Turnover', 'Volume', 'Factor',
              'FactorPost', 'Pause']  #需要保留的字段名称
    multi_index = pd.MultiIndex.from_product([code_list, ziduan])
    # 获取时间序列
    clock_list = list(price_ori['Clock'].drop_duplicates(keep='first'))
    time_list = []
    for time in clock_list:
        time_list.append(dt.datetime.strptime(time, '%Y-%m-%d'))
    # 格式转换
    price_ori = price_ori.set_index(price_ori['Symbol'])
    price = pd.DataFrame(index=multi_index, columns=time_list)
    _pbar = progressbar.ProgressBar(len(code_list))
    _pbar.start()
    for idx, code in enumerate(code_list):
        xx = price_ori.loc[code, ziduan]
        if price.shape[1] == xx.shape[0]:
            price.loc[code] = np.array(xx.T)
        else:
            yy = price_ori.loc[code]
            if len(yy.shape) > 1:  #有超过1天的数据
                yy = yy.set_index(yy['Clock'])[ziduan]
            else:  #只有一天的数据
                yy1 = pd.DataFrame(index=[yy['Clock']], columns=ziduan)
                yy1.iloc[0, :] = yy[ziduan]
                yy = yy1
            #yy = yy.set_index(yy['Clock'])[ziduan]
            zz = pd.DataFrame(index=clock_list, columns=ziduan)
            zz.loc[yy.index] = yy
            price.loc[code] = np.array(zz.T)
        #price.loc[code] = np.array(price_ori.loc[code,ziduan].T)
        _pbar.update(idx)
    _pbar.finish()
    return price


def stock_valuation_standard(price_ori):
    '''
    将原始估值数据转换为标准的格式
    '''
    if price_ori.shape[0] == 0:
        return pd.DataFrame()

    # 生成双重索引的index
    code_list = list(price_ori['Symbol'].drop_duplicates(keep='first'))
    ziduan = list(price_ori.columns[2:])  #需要保留的字段名称
    multi_index = pd.MultiIndex.from_product([code_list, ziduan])
    # 获取时间序列
    clock_list = list(price_ori['Date'].drop_duplicates(keep='first').sort_values(ascending=True))
    time_list = []
    for time in clock_list:
        time_list.append(dt.datetime.strptime(time, '%Y-%m-%d'))
    # 格式转换
    price_ori = price_ori.set_index(price_ori['Symbol'])
    price = pd.DataFrame(index=multi_index, columns=time_list)
    _pbar = progressbar.ProgressBar(len(code_list))
    _pbar.start()
    for idx, code in enumerate(code_list):
        xx = price_ori.loc[code, ziduan]
        if price.shape[1] == xx.shape[0]:
            price.loc[code] = np.array(xx.T)
        else:
            yy = price_ori.loc[code]
            if len(yy.shape) > 1:  #有超过1天的数据
                yy = yy.set_index(yy['Date'])[ziduan]
            else:  #只有一天的数据
                yy1 = pd.DataFrame(index=[yy['Date']], columns=ziduan)
                yy1.iloc[0, :] = yy[ziduan]
                yy = yy1
            zz = pd.DataFrame(index=clock_list, columns=ziduan)
            zz.loc[yy.index] = yy
            price.loc[code] = np.array(zz.T)
        _pbar.update(idx)
    _pbar.finish()
    return price


def get_all_industry():
    '''
    获取所有的行业列表
    返回行业名称和代码
    '''
    url = common_url + 'get_product' + common_user
    resp = requests.get(url)
    df = pd.DataFrame.from_dict(resp.json()['Data'])
    df = df[df['Type'] == 'INDUSTRIE']  #筛选出行业
    df = df.set_index(df['Code'])
    # 去掉2014年02月21日后废弃的行业代码
    code_list = list(set(df.index) - set(['801060', '801070', '801090', '801100', '801190', '801220']))
    df = df.loc[code_list]
    df = df.set_index(df['Name'])
    stock = df['Symbol']
    return stock


def industry_components(industry, start_date, end_date=None, source='SW1', market='cn'):
    '''
    获取行业股票列表
    industry 行业代码，只能输入一只
    start_date 开始日期（暂时只支持2015-01-01以后的数据）
    end_date 截止日期
    source 行业分类来源，目前只有申万1级行业分类
    market 证券市场
    '''
    if type(start_date) != str:
        start_date = str(start_date)[0:10]
    if type(end_date) != str:
        end_date = str(end_date)[0:10]
    if end_date == 'None':
        end_date = str(dt.datetime.today())[:10]

    if type(industry) == str:
        industry = industry
    elif type(industry) == list:
        industry = ','.join(industry)

    url = common_url + 'stock/get_industry_stocks' + common_user \
          + '&productCode=' + industry + '&start_date=' + start_date + '&end_date=' + end_date
    data = requests.get(url)
    data_df = pd.DataFrame.from_dict(data.json()['Data'])

    data_df = data_df.set_index(data_df['Date'])

    df = data_df[['Industries', 'Stocks']]
    if len(df['Stocks']) == 0:  # 如果没有数据，则返回False并终止函数
        return False

    # industry_series = pd.Series(index=df.index)
    # for time in df.index:
    #     xx = pd.Series(df[time]).index.to_list()
    #     industry_series.loc[time] = xx

    return df


# 生成行业哑变量 DataFrame
# def get_stock_industry(trade_date, stock_list=None, classify_type='SW1'):
#     """
#     生成行业暴露矩阵，包括所有个股
#     trade_date: 交易日期
#     classify_type: 默认申万1级行业分类
#     """
#     if stock_list == None:
#         stock = all_instruments(type='S')
#         stock = stock[stock['Type']=='STOCK']
#         stock_list = stock['Symbol'].to_list()
#     industry = get_all_industry()
#     sec_industry_df = pd.DataFrame(index=stock_list,columns=industry.index)
#     # 读取行业的成分股
#     for code in industry:
#         name = industry[industry.values==code].index # 找出该行业代码的中文名称
#         #print(name)
#         if type(industry_components(code,trade_date,trade_date))==bool: # 如果没有数据则跳过该行业，继续循环
#             continue
#         xx = industry_components(code,trade_date,trade_date)[0]
#         xx = list(set(xx) & set(stock_list))
#         sec_industry_df.loc[xx,name] = 1

#     sec_industry_df = sec_industry_df.fillna(0)
#     return sec_industry_df
def get_stock_industry(trade_date, stock_list=None, classify_type='SW1'):
    if stock_list == None:
        stock = all_instruments(type='S')
        stock = stock[stock['Type'] == 'STOCK']
        stock_list = stock['Symbol'].to_list()
    stock_industry_df = pd.DataFrame()
    all_industry = Industry.sw1  #get_all_industry()
    # all_industry = get_all_industry()
    stock_series = pd.Series(stock_list).reindex(stock_list)
    industry_components_df = industry_components(all_industry.tolist(), trade_date, trade_date)
    industry_components_df = industry_components_df.set_index(industry_components_df['Industries'])
    for name in industry_components_df.index:
        code_list = list(set(industry_components_df.loc[name, 'Stocks']) & set(stock_list))
        cn_name = all_industry[all_industry.values == name].index  # 找出该行业代码的中文名称
        stock_series.loc[code_list] = cn_name[0]

    stock_industry_df = pd.get_dummies(stock_series)
    return stock_industry_df.astype(np.float)


# 获取个股估值信息
def get_stock_valuation(productCode, start_date, end_date=None, fields=None):
    '''
    productCode 股票代码
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期
    fields 字段（如下）
    '''
    # Capitalization	总股本(万股)	公司已发行的普通股股份总数(包含A股，B股和H股的总股本)	
    # CirculatingCap	流通股本(万股)	公司已发行的境内上市流通、以人民币兑换的股份总数(A股市场的流通股本)	
    # MarketCap	总市值(亿元)	A股收盘价*已发行股票总股本（A股+B股+H股）	
    # CirculatingMarketCap	流通市值(亿元)	流通市值指在某特定时间内当时可交易的流通股股数乘以当时股价得出的流通股票总价值。	A股市场的收盘价*A股市场的流通股数
    # TurnoverRatio	换手率(%)	指在一定时间内市场中股票转手买卖的频率，是反映股票流通性强弱的指标之一。	换手率=[指定交易日成交量(手)100/截至该日股票的流通股本(股)]100%
    # PeRatio	市盈率(PE, TTM)	每股市价为每股收益的倍数，反映投资人对每元净利润所愿支付的价格，用来估计股票的投资报酬和风险	市盈率（PE，TTM）=（股票在指定交易日期的收盘价 * 截止当日公司总股本）/归属于母公司股东的净利润TTM。
    # PeRatioLYR	市盈率(PE)	以上一年度每股盈利计算的静态市盈率. 股价/最近年度报告EPS	市盈率（PE）=（股票在指定交易日期的收盘价 * 截至当日公司总股本）/归属母公司股东的净利润。
    # PBRatio	市净率(PB)	每股股价与每股净资产的比率	市净率=（股票在指定交易日期的收盘价 * 截至当日公司总股本）/归属母公司股东的权益。
    # PSRatio	市销率(PS, TTM)	市销率为股票价格与每股销售收入之比，市销率越小，通常被认为投资价值越高。	市销率TTM=（股票在指定交易日期的收盘价 * 截至当日公司总股本）/营业总收入TTM
    # PCFRatio	市现率(PCF, 现金净流量TTM)	每股市价为每股现金净流量的倍数	市现率=（股票在指定交易日期的收盘价 * 截至当日公司总股本）/现金及现金等价物净增加额TTM
    if type(productCode) == str:  #输入为一只股票
        stock_id = productCode
        n = 0
    else:  #输入为多只股票
        productCode = list(productCode)
        n = np.ceil(len(productCode) / 50)  #向上取整
        stock_id = ','.join(productCode[:50])

    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'stock/get_valuation?'
    data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
            'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
    resp = requests.post(url, data=data)
    df = pd.DataFrame.from_dict(resp.json()['Data'])

    if n > 1.0:
        _pbar = progressbar.ProgressBar(n)
        print('估值数据下载中……')
        _pbar.start()
        for m in range(1, int(n)):
            stock_id = ','.join(productCode[50 * m:50 * m + 50])
            data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
                    'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
            resp = requests.post(url, data=data)
            df_1 = pd.DataFrame.from_dict(resp.json()['Data'])
            df = pd.concat([df, df_1], axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('估值数据下载完成！')

    if fields == None:
        return df
    else:
        return df.loc[:, ['Date', 'Symbol', fields]]


# 获取个股常用的财务指标数据
def get_indicator(productCode, start_date, end_date=None, fields=None):
    '''
    productCode 股票代码
    start_date 开始日期（暂时只支持2010-03-31以后的数据）
    end_date 截止日期
    fields 字段（如下）
    '''

    if type(productCode) == str:  #输入为一只股票
        stock_id = productCode
        n = 0
    else:  #输入为多只股票
        productCode = list(productCode)
        n = np.ceil(len(productCode) / 50)  #向上取整
        stock_id = ','.join(productCode[:50])

    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'stock/get_indicator?'
    data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
            'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
    resp = requests.post(url, data=data)
    df = pd.DataFrame.from_dict(resp.json()['Data'])

    if n > 1.0:
        _pbar = progressbar.ProgressBar(n)
        print('财务指标下载中……')
        _pbar.start()
        for m in range(1, int(n)):
            stock_id = ','.join(productCode[50 * m:50 * m + 50])
            data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
                    'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
            resp = requests.post(url, data=data)
            if 'Data' in resp.json():
                df_1 = pd.DataFrame.from_dict(resp.json()['Data'])
            else:
                continue
            df = pd.concat([df, df_1], axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('财务指标下载完成！')

    if fields == None:
        return df
    else:
        return df.loc[:, ['Date', 'Symbol', fields]]


def stock_finance_standard(price_ori):
    '''
    将原始财务数据转换为标准的格式
    '''

    # 生成双重索引的index
    code_list = list(price_ori['Symbol'].drop_duplicates(keep='first'))
    ziduan = list(price_ori.columns[1:])  #需要保留的字段名称
    multi_index = pd.MultiIndex.from_product([code_list, ziduan])
    # 获取时间序列
    clock_list = list(price_ori['StatDate'].drop_duplicates(keep='first').sort_values(ascending=True))
    time_list = []
    for time in clock_list:
        time_list.append(dt.datetime.strptime(time, '%Y-%m-%d'))
    # 格式转换
    price_ori.set_index('Symbol', inplace=True)
    price = pd.DataFrame(index=multi_index, columns=time_list)
    _pbar = progressbar.ProgressBar(len(code_list))
    _pbar.start()
    for idx, code in enumerate(code_list):
        xx = price_ori.loc[code, ziduan]
        if price.shape[1] == xx.shape[0]:
            price.loc[code] = np.array(xx.T)
        else:
            yy = price_ori.loc[code]
            if len(yy.shape) > 1:  #有超过1天的数据
                yy = yy.set_index(yy['StatDate'])[ziduan]
            else:  #只有一天的数据
                yy1 = pd.DataFrame(index=[yy['StatDate']], columns=ziduan)
                yy1.iloc[0, :] = yy[ziduan]
                yy = yy1
            zz = pd.DataFrame(index=clock_list, columns=ziduan)
            zz.loc[yy.index] = yy
            price.loc[code] = np.array(zz.T)
        _pbar.update(idx)
    _pbar.finish()
    return price


# 获取个股利润表数据
def get_income(productCode, start_date, end_date=None, fields=None):
    '''
    productCode 股票代码
    start_date 开始日期（暂时只支持2010-03-31以后的数据）
    end_date 截止日期
    fields 字段（如下）
    '''

    if type(productCode) == str:  #输入为一只股票
        stock_id = productCode
        n = 0
    else:  #输入为多只股票
        productCode = list(productCode)
        n = np.ceil(len(productCode) / 50)  #向上取整
        stock_id = ','.join(productCode[:50])

    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'stock/get_income?'
    data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
            'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
    resp = requests.post(url, data=data)
    df = pd.DataFrame.from_dict(resp.json()['Data'])

    if n > 1.0:
        _pbar = progressbar.ProgressBar(n)
        print('利润表数据下载中……')
        _pbar.start()
        for m in range(1, int(n)):
            stock_id = ','.join(productCode[50 * m:50 * m + 50])
            data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
                    'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
            resp = requests.post(url, data=data)
            if 'Data' in resp.json():
                df_1 = pd.DataFrame.from_dict(resp.json()['Data'])
            else:
                continue
            df = pd.concat([df, df_1], axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('利润表数据下载完成！')

    if fields == None:
        return df
    else:
        return df.loc[:, ['Date', 'Symbol', fields]]


# 获取个股资产负债表数据
def get_balance(productCode, start_date, end_date=None, fields=None):
    '''
    productCode 股票代码
    start_date 开始日期（暂时只支持2010-03-31以后的数据）
    end_date 截止日期
    fields 字段（如下）
    '''

    if type(productCode) == str:  #输入为一只股票
        stock_id = productCode
        n = 0
    else:  #输入为多只股票
        productCode = list(productCode)
        n = np.ceil(len(productCode) / 50)  #向上取整
        stock_id = ','.join(productCode[:50])

    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'stock/get_balance?'
    data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
            'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
    resp = requests.post(url, data=data)
    df = pd.DataFrame.from_dict(resp.json()['Data'])

    if n > 1.0:
        _pbar = progressbar.ProgressBar(n)
        print('资产负债表数据下载中……')
        _pbar.start()
        for m in range(1, int(n)):
            stock_id = ','.join(productCode[50 * m:50 * m + 50])
            data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
                    'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
            resp = requests.post(url, data=data)
            if 'Data' in resp.json():
                df_1 = pd.DataFrame.from_dict(resp.json()['Data'])
            else:
                continue
            df = pd.concat([df, df_1], axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('资产负债表数据下载完成！')

    if fields == None:
        return df
    else:
        return df.loc[:, ['Date', 'Symbol', fields]]


# 获取现金流量表数据
def get_cash_flow(productCode, start_date, end_date=None, fields=None):
    '''
    productCode 股票代码
    start_date 开始日期（暂时只支持2010-03-31以后的数据）
    end_date 截止日期
    fields 字段（如下）
    '''

    if type(productCode) == str:  #输入为一只股票
        stock_id = productCode
        n = 0
    else:  #输入为多只股票
        productCode = list(productCode)
        n = np.ceil(len(productCode) / 50)  #向上取整
        stock_id = ','.join(productCode[:50])

    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'stock/get_cashflow?'
    data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
            'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
    resp = requests.post(url, data=data)
    df = pd.DataFrame.from_dict(resp.json()['Data'])

    if n > 1.0:
        _pbar = progressbar.ProgressBar(n)
        print('现金流量表数据下载中……')
        _pbar.start()
        for m in range(1, int(n)):
            stock_id = ','.join(productCode[50 * m:50 * m + 50])
            data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
                    'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
            resp = requests.post(url, data=data)
            if 'Data' in resp.json():
                df_1 = pd.DataFrame.from_dict(resp.json()['Data'])
            else:
                continue
            df = pd.concat([df, df_1], axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('现金流量表数据下载完成！')

    if fields == None:
        return df
    else:
        return df.loc[:, ['Date', 'Symbol', fields]]


# 从 stock_finance_info 数据结构中提取对应 finance_name 数据项
def exact_finance_data(finance_name, finance_df, end_date=None, period='all'):
    """
    finance_name: 财务数据名称
    end_date: 提取数据 DataFrame 截止日期
    period: 选择周期,half-半年, year-年, all-全部
    finance_df: 财报数据格式 DF， stock_finance_info
    """
    # 选取报告期数据
    if period == 'half':
        rpt_month_list = [6, 12]
        pass
    elif period == 'year':
        rpt_month_list = [12]
        pass
    elif period == 'all':
        rpt_month_list = [3, 6, 9, 12]
        pass
    else:
        raise Exception('error')
        pass
    rpt_list = []
    for rpt_date in finance_df.columns:
        if rpt_date.month in rpt_month_list:
            rpt_list.append(rpt_date)
            pass
    finance_df = finance_df.reindex(columns=rpt_list)

    all_items_list = finance_df.index.get_level_values(level=1).drop_duplicates().tolist()

    if finance_name not in all_items_list:
        raise Exception('error: 无输入财务数据！')
        pass

    all_stock_list = finance_df.index.get_level_values(level=0).drop_duplicates().tolist()
    finance_df = finance_df.loc[pd.MultiIndex.from_product([all_stock_list, ['PubDate', finance_name]])]

    # 获取交易日期
    if end_date is None:
        common_date_list = get_trading_dates(str(finance_df.columns.min())[:10], str(finance_df.columns.max())[:10])
    else:
        common_date_list = get_trading_dates(str(finance_df.columns.min())[:10], end_date)

    # 提取财务因子并根据发布日填充数据
    pbar = progressbar.ProgressBar(len(all_stock_list))
    pbar.start()
    extract_data_dict = {}
    for idx, sec_code in enumerate(all_stock_list):
        stock_finance_df = finance_df.loc[sec_code].T.drop_duplicates('PubDate', keep='last').dropna()
        stock_finance_series = stock_finance_df.set_index('PubDate').iloc[:, 0]
        stock_finance_series.index.name = None
        extract_data_dict[sec_code] = stock_finance_series
        pbar.update(idx)
    extract_data_df = pd.DataFrame(extract_data_dict).T
    extract_data_df = extract_data_df.reindex(columns=common_date_list).ffill(axis=1).dropna(axis=1, how='all')
    common_date_series = pd.Series(extract_data_df.columns).apply(
        lambda x: dt.datetime.strptime(x, '%Y-%m-%d'))  #将列修改为标准日期格式
    extract_data_df.columns = common_date_series
    pbar.finish()

    return extract_data_df


def get_st_stock(ProductCode, start_date, end_date=None):
    '''
    获取股票在某一时间段是否为st股票
    '''
    if type(ProductCode) == str:  #输入为一只股票
        stock_id = ProductCode
        n = 0
    else:  #输入为多只股票
        ProductCode = list(ProductCode)
        n = np.ceil(len(ProductCode) / 50)  #向上取整
        stock_id = ','.join(ProductCode[:50])

    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days=-1, minutes=0, seconds=0)
        end_date = str(yesterday)[:10]

    url = common_url + 'stock/get_st_stock' + common_user \
          + '&productCode=' + stock_id + '&start_date=' + start_date + '&end_date=' + end_date
    data = requests.get(url)
    data_df = pd.DataFrame.from_dict(data.json()['Data'])
    if n <= 1.0:
        pass
    else:
        _pbar = progressbar.ProgressBar(n)
        print('数据下载中……')
        _pbar.start()
        for m in range(1, int(n)):
            stock_id = ','.join(ProductCode[50 * m:50 * m + 50])
            url = common_url + 'stock/get_st_stock' + common_user + '&productCode=' + stock_id + '&start_date=' + start_date + '&end_date=' + end_date
            data = requests.get(url)
            df_1 = pd.DataFrame.from_dict(data.json()['Data'])
            data_df = pd.concat([data_df, df_1], axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('数据下载完成！')
    # 将数据标准化
    # 生成双重索引的index
    if data_df.shape[0] == 0:
        print('没有数据！')
        return False
    code_list = list(data_df['ProductCode'].drop_duplicates(keep='first'))
    ziduan = list(['IsST', 'UpDateTime'])  #需要保留的字段名称
    multi_index = pd.MultiIndex.from_product([code_list, ziduan])
    # 获取时间序列
    clock_list = list(data_df['SymbolDate'].drop_duplicates(keep='first').sort_values(ascending=True))
    time_list = []
    for time in clock_list:
        time_list.append(dt.datetime.strptime(time, '%Y-%m-%d'))
    # 格式转换
    data_df.set_index('ProductCode', inplace=True)
    price = pd.DataFrame(index=multi_index, columns=time_list)
    _pbar = progressbar.ProgressBar(len(code_list))
    _pbar.start()
    for idx, code in enumerate(code_list):
        xx = data_df.loc[code, ziduan]
        if price.shape[1] == xx.shape[0]:
            price.loc[code] = np.array(xx.T)
        else:
            yy = data_df.loc[code]
            if len(yy.shape) > 1:  #有超过1天的数据
                yy = yy.set_index(yy['SymbolDate'])[ziduan]
            else:  #只有一天的数据
                yy1 = pd.DataFrame(index=[yy['SymbolDate']], columns=ziduan)
                yy1.iloc[0, :] = yy[ziduan]
                yy = yy1
            zz = pd.DataFrame(index=clock_list, columns=ziduan)
            zz.loc[yy.index] = yy
            price.loc[code] = np.array(zz.T)
        _pbar.update(idx)
    _pbar.finish()
    return price


# 获取个股除权除息数据
def get_xrxd(productCode, start_date, end_date=None):
    '''
    productCode 股票代码
    start_date 开始日期（A股股权登记日）
    end_date 结束日期（A股股权登记日）
    '''

    if type(productCode) == str:  #输入为一只股票
        stock_id = productCode
        n = 0
    else:  #输入为多只股票
        productCode = list(productCode)
        n = np.ceil(len(productCode) / 50)  #向上取整
        stock_id = ','.join(productCode[:50])

    if end_date == None:
        end_date = str(dt.datetime.today())[:10]

    url = common_url + 'stock/get_xrxd?'
    data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
            'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
    resp = requests.post(url, data=data)
    df = pd.DataFrame.from_dict(resp.json()['Data'])

    if n > 1.0:
        _pbar = progressbar.ProgressBar(n)
        print('除权除息数据下载中……')
        _pbar.start()
        for m in range(1, int(n)):
            stock_id = ','.join(productCode[50 * m:50 * m + 50])
            data = {'username': username, 'password': password, 'version': version, 'pythonNo': login.pythonNo,
                    'productCode': stock_id, 'start_date': start_date, 'end_date': end_date}
            resp = requests.post(url, data=data)
            if 'Data' in resp.json():
                df_1 = pd.DataFrame.from_dict(resp.json()['Data'])
            else:
                continue
            df = pd.concat([df, df_1], axis=0)
            _pbar.update(m)
        _pbar.finish()
        print('除权除息数据下载完成！')
    return df


if __name__ == '__main__':
    # 接口测试
    print(get_all_industry())
    print(industry_components('S.CN.INBS.801740', '2015-10-09', '2020-10-10'))
    print(get_stock_industry('2020-10-09'))
    print(get_stock_valuation('S.CN.SZSE.000001', '2020-09-11', '2020-09-22'))
