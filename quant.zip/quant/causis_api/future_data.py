#从服务器提取原始数据
# import sys,os
# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# sys.path.append(BASE_DIR)
import requests
import numpy as np
import pandas as pd
import datetime as dt
from causis_api.const import login
from causis_api.http_request_handler import HTTPRequestHandler
import urllib.parse
import matplotlib.pylab as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
import progressbar

username = login.username
password = login.password
version = login.version

common_url = login.common_url + 'future/'
common_user = '?username=' + username + '&password=' + password + '&version=' + version + '&pythonNo=' + login.pythonNo

def get_dominant_contracts(ProductCode,start_date,end_date=None):
    '''
    获取主力合约
    返回dataframe，包括日期、代码、内部编码
	ProductCode 期货内部代码
	start_date 开始日期
	end_date 截止日期
    '''
    # post方法不行？
    # url = 'http://cnb2.causis.com.cn:53109/future/get_dominant?'
    # data = {'username':'zhangyi','password':'123qwe','symbol':ProductCode,'start_date':start_date,'end_date':end_date}
    # resp = requests.post(url,data=data)
    # df = pd.DataFrame.from_dict(resp.json()['Data'])
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
        #end_date = str(dt.datetime.today())[:10]
    url = common_url + 'get_dominant' + common_user \
            + '&symbol=' + ProductCode + '&start_date=' + start_date + '&end_date=' + end_date 
    data = requests.get(url)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    if df.shape[0]==0:
        return df
    dominant = pd.DataFrame()
    dominant['Date'] = df['Date']
    dominant['ProductCode'] = df['Symbol']
    return dominant

def get_available_contracts(ProductCode,date):
    '''
    获取可交易合约
    返回list
	ProductCode 简称代码
	date 日期
    '''
    # post方法不行？
    # url = 'http://cnb2.causis.com.cn:53109/future/get_contracts?'
    # data = {'username':'zhangyi','password':'123qwe','symbol':ProductCode,'date':date}
    # resp = requests.post(url,data=data)
    # df = pd.DataFrame.from_dict(resp.json()['Data'])
    url = common_url + 'get_contracts' + common_user  \
            + '&symbol=' + ProductCode + '&date=' + date
    data = requests.get(url)
    future_list = data.json()['Data']
    return future_list

def get_roll_price(ProductCode, start_date, end_date=None, frequency='day'):
    '''
    获取连续合约在一段时间内换月当日的行情信息
    ProductCode 连续合约代码
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期
    frequency 数据频率（day,minute默认为日频） 
    '''
    stock_id = ProductCode
    
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
        # end_date = today
    
    # get方法
    if frequency == 'day':
        url = common_url + 'get_roll_day_price' + common_user \
                + '&productCode=' + stock_id + '&start_date=' + start_date + '&end_date=' + end_date 
    elif frequency == 'minute':
        url = common_url + 'get_roll_min_price' + common_user + '&productCode=' + stock_id \
                 + '&start_date=' + start_date + '&end_date=' + end_date

    data = requests.get(url)
    df = pd.DataFrame.from_dict(data.json()['Data'])
    
    return df


def get_fundamental_index(ProductCode=None):
    """
    作者：肖文清
    根据品种代码获取基本面指标信息
    返回DataFrame
	ProductCode 品种代码，例:F.CN.SHF.RB，不传或传空，获取所有
    """
    # post方式
    # req = {'username': 'zhangyi', 'password': '123qwe', 'variCode': VariCode, 'pythonNo': login.pythonNo,
    #        'version': version}
    # url = common_url + 'get_tf_index'
    # print('http post:')
    # data = requests.post(url, data=req)
    # return data.json()['Data']

    url = common_url + 'get_fundamental_index' + common_user \
          + "&varicode=" + str(ProductCode or '')

    data = requests.get(url)

    return pd.DataFrame(data.json()['Data'])


def get_symbol_value(symbol, start_date, end_date=None):
    """
    作者：肖文清
    根据商品期货基本面指标名称，获取对应的指标值
    返回DataFrame
	symbol 指标名称，取值为 get_fundamental_index接口返回的Symbol字段
	start_date 起始日期
	end_date 结束日期，默认None，截止当天时间(如果有，包含当天数据)
    """
    if end_date is None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        end_date = str(today)[:10]
    url = common_url + 'get_symbol_value' + common_user \
          + "&symbol=" + urllib.parse.quote(str(symbol or '')) + '&start_date=' + start_date + '&end_date=' + end_date

    data = requests.get(url)
    result = data.json()['Data']
    return pd.DataFrame(result)

def get_symbol_value_by_update(symbol, start_date, end_date=None):
    """
    根据商品期货基本面指标名称，获取对应的指标值，接口会根据入库时间返回对应的数据
    返回DataFrame
	symbol 指标名称，取值为 get_fundamental_index接口返回的Symbol字段
	start_date 起始日期
	end_date 结束日期，默认None，截止当天时间(如果有，包含当天数据)
    """
    if end_date is None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        end_date = str(today)[:10]
    url = common_url + 'get_symbol_value_by_update' + common_user \
          + "&symbol=" + urllib.parse.quote(str(symbol or '')) + '&start_date=' + start_date + '&end_date=' + end_date

    data = requests.get(url)
    result = data.json()['Data']
    return pd.DataFrame(result)


def get_symbol_value_investigated(symbol, start_date, end_date=None):
    """
    提供研究使用的，最新天风数据源获取的基本面数据；（每周全量更新）
    根据商品期货基本面指标名称，获取对应的指标值
    返回DataFrame
	symbol 指标名称，取值为 get_fundamental_index接口返回的Symbol字段
	start_date 起始日期
	end_date 结束日期，默认None，截止当天时间(如果有，包含当天数据)
    """
    if end_date is None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        end_date = str(today)[:10]
    investigated_url = 'http://58.49.210.250:59998/future/'
    url = investigated_url + 'get_symbol_value' + common_user \
          + "&symbol=" + urllib.parse.quote(str(symbol or '')) + '&start_date=' + start_date + '&end_date=' + end_date

    data = requests.get(url)
    result = data.json()['Data']
    return pd.DataFrame(result)

def get_symbol_value_by_delay(symbol, start_date, end_date=None,delay=0):
    """
    根据商品期货基本面指标名称，获取对应的指标值，接口会根据入库时间返回对应的数据（提供延迟时间设置）
    获取库存基本面数据    返回DataFrame
	symbol 指标名称，取值为 get_fundamental_index接口返回的Symbol字段
	start_date 起始日期
	end_date 结束日期，默认None，截止当天时间(如果有，包含当天数据)
	delay 延迟天数，默认0
    """
    if end_date is None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        end_date = str(today)[:10]
    url = common_url + 'get_symbol_value_by_delay' + common_user \
          + "&symbol=" + urllib.parse.quote(str(symbol or '')) + '&start_date=' + start_date + '&end_date=' + end_date+'&delay='+str(delay)

    data = requests.get(url)
    result = data.json()['Data']
    return pd.DataFrame(result)
    
def get_hold_position(productCode, topN, start_date, end_date=None):
    """
    作者：肖文清
    获取期货品种持仓量
    :param productCode:系统内的代码，形如F.CN.SHF.ag (不区分大小写)
    :param topN:top5/top10/top20
    :param start_date:起始日期(包含)
    :param end_date:结束日期(包含)
    """
    if end_date is None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        end_date = str(today)[:10]
    url = common_url + 'get_hold_position' + common_user \
          + "&productCode=" + str(
        productCode or '') + '&topN=' + topN + '&start_date=' + start_date + '&end_date=' + end_date

    data = requests.get(url)
    result = data.json()['Data']
    return pd.DataFrame(result)


def get_active_futures_product(top, window, start_date, end_date=None):
    """
    作者：肖文清
    获取活跃期货品种(如：F.CN.CFE.IF)日均成交额排名
    :param top:取每天的前N个品种
    :param window:回看日期 (即计算某个指定日期的数据时，需要计算前面Window天的所有合约日均成交金额)
    :param start_date:起始日期(包含)
    :param end_date:结束日期(包含)，不填默认为当天
    """
    if end_date is None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        end_date = str(today)[:10]
    url = common_url + 'get_active_futures_product' + common_user \
          + "&top=" + str(top) + '&window=' + str(window) + '&start_date=' + start_date + '&end_date=' + end_date

    data = requests.get(url)
    result = data.json()['Data']
    return pd.DataFrame(result)

def get_external_min_bar(ProductCode, start_date, end_date=None,frequency='minute1'):
    '''
    作者：许泽文、陈振华
    获取外盘期货分钟行情信息
    ProductCode 标的代码:
    |@CT#|洲际交易所|F.US.ICE.CT|棉花|
    |QCL|纽约商业期货交易所|F.US.NYMEX.QCL|小型原油|
    |QSI#|纽约商业交易所|F.US.COMEX.QSI|白银|
    |QHG#|纽约商业交易所|F.US.COMEX.QHG|精铜|
    |@S#|芝加哥商品交易所集团|F.US.CBOT.S|黄豆|
    |@BO#|芝加哥商品交易所集团|F.US.CBOT.BO|豆油|
    |KPO#|马来西亚证券交易所|F.MY.MDEX.KPO|棕榈油|
    |QGC#|纽约商业交易所|F.US.COMEX.QGC|黄金|
    start_date 开始日期（暂时只支持2015-01-01以后的数据）
    end_date 截止日期
    frequency 数据频率（minute1,minute5,minute15,minute30,minute60..）
    '''
    stock_id = ProductCode
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
    url = common_url + 'get_external_min_bar' + common_user + '&productCode=' + stock_id \
        + '&start_date=' + start_date + '&end_date=' + end_date+ '&minute=' + frequency[6:]
    # data = requests.get(url)
    # df = pd.DataFrame.from_dict(data.json()['Data'])
    # return df[["ProductCode","BarTime","Open","Close","Low","High","Volume","TotalVolume","ADJ"]]
    data = {'username':username,'password':password,'version':version, 'pythonNo':login.pythonNo, 'productCode':stock_id,'start_date':start_date,'end_date':end_date,'minute':frequency[6:]}
    resp = requests.post(url,data=data)
    df = pd.DataFrame.from_dict(resp.json()['Data'])
    if resp.json()['Code']==None and df.shape[1]>0:
        return df[["SYMBOL","CLOCK","OPEN","HIGH","LOW","CLOSE","VOLUME","ADJ"]]
    # str(resp.json()['Code'])    
    print(f"{str(resp.json()['Code'])}:{str(resp.json()['Msg'])}")    
    return df

def get_price_product(productCode):
    """
    获取期货品种的全部日线数据
    :param productCode:合约代码
    """
    if type(productCode) == str:#输入为一只股票
        stock_id = productCode
    else:                       #输入为多只股票
        productCode = list(productCode)
        stock_id = ','.join(productCode)

    url = common_url + 'get_price_product' + common_user + "&productCode=" + stock_id 

    data = requests.get(url)
    result = data.json()['Data']
    return pd.DataFrame(result)

def future_price_standard(price_ori):
    '''
    将原始期货行情数据转换为标准的格式
    '''
    
    # 生成双重索引的index
    code_list = list(price_ori['SYMBOL'].drop_duplicates(keep='first'))
    ziduan = list(price_ori.columns[2:]) #需要保留的字段名称
    multi_index = pd.MultiIndex.from_product([code_list,ziduan])
    # 获取时间序列
    clock_list = list(price_ori['CLOCK'].drop_duplicates(keep='first').sort_values(ascending=True))
    time_list = []
    for time in clock_list:
        time_list.append(dt.datetime.strptime(time, '%Y-%m-%d'))
    # 格式转换
    price_ori = price_ori.set_index(price_ori['SYMBOL'])
    price = pd.DataFrame(index=multi_index,columns=time_list)
    _pbar = progressbar.ProgressBar(len(code_list))
    _pbar.start()
    for idx,code in enumerate(code_list):
        xx = price_ori.loc[code,ziduan]
        if price.shape[1] == xx.shape[0]:
            price.loc[code] = np.array(xx.T)
        else:
            yy = price_ori.loc[code]
            if len(yy.shape) > 1:      #有超过1天的数据
                yy = yy.set_index(yy['CLOCK'])[ziduan]
            else:                    #只有一天的数据
                yy1 = pd.DataFrame(index=[yy['CLOCK']],columns=ziduan)
                yy1.iloc[0,:] = yy[ziduan]
                yy = yy1
            zz = pd.DataFrame(index=clock_list,columns=ziduan)
            zz.loc[yy.index] = yy
            price.loc[code] = np.array(zz.T)
        _pbar.update(idx)
    _pbar.finish()
    return price

def minute_price_standard(price_ori):
    '''
    将分钟数据转换为标准的格式
    '''
    
    # 生成双重索引的index
    code_list = list(price_ori['SYMBOL'].drop_duplicates(keep='first'))
    ziduan = list(price_ori.columns[2:]) #需要保留的字段名称
    multi_index = pd.MultiIndex.from_product([code_list,ziduan])
    # 获取时间序列
    clock_list = list(price_ori['CLOCK'].drop_duplicates(keep='first').sort_values(ascending=True))
    time_list = []
    for time in clock_list:
        time_list.append(dt.datetime.strptime(time, '%Y-%m-%d %H:%M:%S'))
    # 格式转换
    price_ori = price_ori.set_index(price_ori['SYMBOL'])
    price = pd.DataFrame(index=multi_index,columns=time_list)
    _pbar = progressbar.ProgressBar(len(code_list))
    _pbar.start()
    for idx,code in enumerate(code_list):
        xx = price_ori.loc[code,ziduan]
        if price.shape[1] == xx.shape[0]:
            price.loc[code] = np.array(xx.T)
        else:
            yy = price_ori.loc[code]
            if len(yy.shape) > 1:      #有超过1天的数据
                yy = yy.set_index(yy['CLOCK'])[ziduan]
            else:                    #只有一天的数据
                yy1 = pd.DataFrame(index=[yy['CLOCK']],columns=ziduan)
                yy1.iloc[0,:] = yy[ziduan]
                yy = yy1
            zz = pd.DataFrame(index=clock_list,columns=ziduan)
            zz.loc[yy.index] = yy
            price.loc[code] = np.array(zz.T)
        _pbar.update(idx)
    _pbar.finish()
    return price


def get_external_min_bar_new(ProductCode, start_date, end_date=None,frequency='minute1'):
    '''
    作者：陈振华
    获取外盘期货分钟行情信息
    ProductCode 标的代码:
    |@CT#|洲际交易所|F.US.ICE.CT|棉花|
    |QCL|纽约商业期货交易所|F.US.NYMEX.QCL|小型原油|
    |QSI#|纽约商业交易所|F.US.COMEX.QSI|白银|
    |QHG#|纽约商业交易所|F.US.COMEX.QHG|精铜|
    |@S#|芝加哥商品交易所集团|F.US.CBOT.S|黄豆|
    |@BO#|芝加哥商品交易所集团|F.US.CBOT.BO|豆油|
    |KPO#|马来西亚证券交易所|F.MY.MDEX.KPO|棕榈油|
    |QGC#|纽约商业交易所|F.US.COMEX.QGC|黄金|
    start_date 开始日期（暂时只支持2015-01-01以后的数据）
    end_date 截止日期
    frequency 数据频率（minute1,minute5,minute15,minute30,minute60..）
    '''
    stock_id = ProductCode
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
    data = {'productCode':stock_id,'start_date':start_date,'end_date':end_date,'minute':frequency[6:]}
    handler = HTTPRequestHandler()
    # resp = handler.post(endpoint='future/get_external_min_bar', json=data)
    resp = handler.post(endpoint='future/get_external_min_bar', data=data)
    json= handler.process_http_response(resp)
    if json is not None:
        df = pd.DataFrame.from_dict(json)
        if resp.json()['Code']==None and df.shape[1]>0:
            return df[["SYMBOL","CLOCK","OPEN","HIGH","LOW","CLOSE","VOLUME","ADJ"]]
    return json



def get_future_rank(ProductCode, start_date, end_date=None,topN=10):
    '''
    作者：陈振华
    获取期货排名信息
    ProductCode 标的代码:0004按持仓量排名，0005按成交量排名 如：T.CN.CFE.IC.0004,T.CN.CZC.CY.0005
    start_date 开始日期（暂时只支持2010-01-01以后的数据）
    end_date 截止日期
    topN 排名（获取小于等于该排名的合约信息）
    '''
    stock_id = ProductCode
    if end_date == None:
        today = str(dt.datetime.today())[0:10]
        today = dt.datetime.strptime(today, '%Y-%m-%d')
        yesterday = today + dt.timedelta(days = -1, minutes = 0, seconds = 0)
        end_date = str(yesterday)[:10]
    data = {'productCode':stock_id,'start_date':start_date,'end_date':end_date,'topN':topN}
    handler = HTTPRequestHandler()
    # resp = handler.post(endpoint='future/get_external_min_bar', json=data)
    resp = handler.post(endpoint='future/get_future_rank', data=data)
    json= handler.process_http_response(resp)
    if json is not None:
        df = pd.DataFrame.from_dict(json)
        return  df
    return json
if __name__ == '__main__':
    # 接口测试
    print(get_dominant_contracts('R.CN.CFE.IC','2020-09-15','2020-09-22'))
    print(get_available_contracts('IC','2020-09-22'))

    data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\ATBW011.csv")
    data.index = pd.to_datetime(data.level_0)
    test_data = pd.read_csv("C:\\Users\\zhangyi\\Desktop\\谭博文\\Balance-20210719.csv")
    # result = DrawdownOverlapAnalysis(data.adj_result,StrategyName="ATBW011",test=test_data)
    